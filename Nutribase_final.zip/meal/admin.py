from django.contrib import admin
from meal.models import Meal

# Register your models here.

